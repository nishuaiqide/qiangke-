package xyz.zhzh;

class MySetting {
    static String SECRETE_URL = "http://xk.zucc.edu.cn/CheckCode.aspx";

    static String IMG_DOWN = "./data/downloads/";

    // 字模位置
    static String MODEL_ROOT = "./data/model";
    static String MODEL = "./data/model/";

    // 识别结果
    static String IMG_RESULT = "./data/result/";

    // 每次下载的数量
    static int count = 100;
}
